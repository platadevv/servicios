<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'xiang', 'nong', 'bo', 'chan', 'lan', 'ju', 'shuang', 'she', 'wei', 'cong', 'quan', 'qu', 'cang', 'jiu', 'yu', 'luo',
  0x10 => 'li', 'cuan', 'luan', 'dang', 'jue', 'yan', 'lan', 'lan', 'zhu', 'lei', 'li', 'ba', 'nang', 'yu', 'ling', 'guang',
  0x20 => 'qian', 'ci', 'huan', 'xin', 'yu', 'yi', 'qian', 'ou', 'xu', 'chao', 'chu', 'qi', 'kai', 'yi', 'jue', 'xi',
  0x30 => 'xu', 'he', 'yu', 'kui', 'lang', 'kuan', 'shuo', 'xi', 'ai', 'yi', 'qi', 'chua', 'chi', 'qin', 'kuan', 'kan',
  0x40 => 'kuan', 'kan', 'chuan', 'sha', 'gua', 'yin', 'xin', 'xie', 'yu', 'qian', 'xiao', 'ye', 'ge', 'wu', 'tan', 'jin',
  0x50 => 'ou', 'hu', 'ti', 'huan', 'xu', 'pen', 'xi', 'xiao', 'chua', 'she', 'shan', 'han', 'chu', 'yi', 'e', 'yu',
  0x60 => 'chuo', 'huan', 'zhi', 'zheng', 'ci', 'bu', 'wu', 'qi', 'bu', 'bu', 'wai', 'ju', 'qian', 'chi', 'se', 'chi',
  0x70 => 'se', 'zhong', 'sui', 'sui', 'li', 'cuo', 'yu', 'li', 'gui', 'dai', 'e', 'si', 'jian', 'zhe', 'mo', 'mo',
  0x80 => 'yao', 'mo', 'cu', 'yang', 'tian', 'sheng', 'dai', 'shang', 'xu', 'xun', 'shu', 'can', 'jue', 'piao', 'qia', 'qiu',
  0x90 => 'su', 'qing', 'yun', 'lian', 'yi', 'fou', 'zhi', 'ye', 'can', 'hun', 'dan', 'ji', 'die', 'zhen', 'yun', 'wen',
  0xA0 => 'chou', 'bin', 'ti', 'jin', 'shang', 'yin', 'diao', 'jiu', 'hui', 'cuan', 'yi', 'dan', 'du', 'jiang', 'lian', 'bin',
  0xB0 => 'du', 'jian', 'jian', 'shu', 'ou', 'duan', 'zhu', 'yin', 'qing', 'yi', 'sha', 'qiao', 'ke', 'xiao', 'xun', 'dian',
  0xC0 => 'hui', 'hui', 'gu', 'qiao', 'ji', 'yi', 'ou', 'hui', 'duan', 'yi', 'xiao', 'wu', 'guan', 'mu', 'mei', 'mei',
  0xD0 => 'ai', 'jie', 'du', 'yu', 'bi', 'bi', 'bi', 'pi', 'pi', 'bi', 'chan', 'mao', 'hao', 'cai', 'pi', 'lie',
  0xE0 => 'jia', 'zhan', 'sai', 'mu', 'tuo', 'xun', 'er', 'rong', 'xian', 'ju', 'mu', 'hao', 'qiu', 'dou', 'sha', 'tan',
  0xF0 => 'pei', 'ju', 'duo', 'cui', 'bi', 'san', 'san', 'mao', 'sai', 'shu', 'yu', 'tuo', 'he', 'jian', 'ta', 'san',
];
